/*
	Einbinden einer HTML datei mit XMLHttpRequest()
	// Glyphs 
*/
function Settingsitem(index,element)
{
	var self = this;
	self.key = index;
	self.html = element.html;
	if(element.Header != undefined)
	{
		self.header = element.Header;
	}
	self.relation = element.Relation;
	self.links = element.Links;
}

function ViewModel_settings()
{
	var self = this;
	self.mainurl = "/php/";
	self.currentrelation = "";
	self.lastrelation = "";
	self.loadedhtml = Array();
	self.collections = Array(); //= ko.observableArray();
	self.objecteditor = Array(); //= ko.observableArray();
	self.general = Array();
	self.getlinksobjecteditor = function(relation)
	{
		for(i in self.objecteditor)
		{
			if(self.objecteditor[i].key == relation)
			{
				return self.objecteditor[i].links;
			}
		}
		
	}
	self.getlinkscollection = function(relation)
	{
		for(i in self.collections)
		{
			if(self.collections[i].key == relation)
			{
				return self.collections[i].links;
			}
		}
		var x = 1;
		
	}
	self.getheadercollection = function(relation)
	{
		for(i in self.collections)
		{
			if(self.collections[i].key == relation)
			{
				return self.collections[i].header;
			}
		}
		var x = 1;
	}
	self.hideobjecteditorhtml = function()
	{
		var objects = $( "#objecteditorcontainer" ).children();
		for (i =0; i < objects.length;i++)
		{
			objects[i].style.display = "none";
		}
		
	}
	self.hidecollectionhtml = function()
	{
		
		var objects = $( "#collectioncontainer" ).children();
		for (i =0; i < objects.length;i++)
		{
			objects[i].style.display = "none";
		}
	}
	self.loadobjecteditor = function(key) //load html page for obecteditor
	{
		for(i in self.objecteditor)
		{
			if(self.objecteditor[i].key == key)
			{
				var relation = self.objecteditor[i].relation;
				if(self.loadedhtml.indexOf(relation) == -1)
				{
					var url = self.objecteditor[i].html;
					if (url == "") { 
						console.log("self.loadobjecteditor return 0");
						return 0; 
					}
					self.hidecollectionhtml();
					//self.loadedhtml.push(relation);
					//jQuery.ajax({"async": false});
					$.ajax({
					  url: url,
					  cache: false,
					  async: false
					})
					  .done(function( html ) {
						self.loadedhtml.push(relation);
						var loaded = $( "#objecteditorcontainer" ).append( html );
						var elements = $( "#objecteditorcontainer" ).children();
						for (i =0; i < elements.length;i++)
						{
							elements[i].style.display = "none";
						}
						ko.applyBindings(objecteditor, document.getElementById(relation));
						$('#'+relation).show();
						//console.log("objecteditor template loaded and shown");
						//$("#collectioncontainer").trigger("loadedhtml", { 'relation': relation});
					  });
//					$( "#collectioncontainer" ).load( url, function( response, status, xhr ){
//						$("#collectioncontainer").trigger("loadedhtml", { 'relation': relation});
//					});
				} else
				{
					self.hidecollectionhtml();
					var elements = $( "#objecteditorcontainer" ).children();
					for (i =0; i < elements.length;i++)
					{
						elements[i].style.display = "none";
					}
					$('#'+relation).show();
					//console.log("objecteditor template shown");
					//$("#collectioncontainer").trigger("loadedhtml", { 'relation': relation});
				}					
			}
		}
	}
	self.loadcollection = function(key,closeable)	// load the HTML page for collection
	{
		var found = 0;
		if(closeable != undefined)
		{
			if(closeable == true)
			{
				var rel = self.currentrelation;
				self.lastrelation = rel;
				
			}
		}
		for(i in self.collections)
		{
			if(self.collections[i].key == key)	// Wenn key gefunden
			{
				var relation = self.collections[i].relation;
				if(self.loadedhtml.indexOf(relation) == -1)
				{
					var url = self.collections[i].html;
					if (url == "") { return 0; }
					self.hideobjecteditorhtml();
					//self.loadedhtml.push(relation);
					//jQuery.ajax({"async": false});
					$.ajax({
					  url: url,
					  cache: false,
					  async: false
					})
					  .done(function( html ) {
						self.loadedhtml.push(relation);
						self.currentrelation = relation;
						var elements = $( "#collectioncontainer" ).children();
						for (i =0; i < elements.length;i++)
						{
							elements[i].style.display = "none";
						}
						var loaded = $( "#collectioncontainer" ).append( html );
						ko.applyBindings(collection, document.getElementById(relation));
						$('#'+relation).show();
						//$("#collectioncontainer").trigger("loadedhtml", { 'relation': relation});
					  });
//					$( "#collectioncontainer" ).load( url, function( response, status, xhr ){
//						$("#collectioncontainer").trigger("loadedhtml", { 'relation': relation});
//					});
				} else
				{
					self.hideobjecteditorhtml();
					var elements = $( "#collectioncontainer" ).children();
					for (i =0; i < elements.length;i++)
					{
						elements[i].style.display = "none";
					}
					$('#'+relation).show();
					self.currentrelation = relation;
					//$("#collectioncontainer").trigger("loadedhtml", { 'relation': relation});
				}
			}
		}
		var x =1;
	}
	self.updatecollection = function(data)
	{
		$.each(data, function(index,element) {
			self.collections.push(new Settingsitem(index,element));
			var x = 1;
		});
	}
	self.updateobjecteditor = function(data)
	{
		$.each(data, function(index,element) {
			self.objecteditor.push(new Settingsitem(index,element));
			var x = 1;
		});
	var x = 0;
	}
	self.update = function(data)
	{
		var jsonstring = JSON.stringify(data);
		var obj = jQuery.parseJSON(jsonstring);
		JSON.parse(jsonstring, function(key,value) {
			if(key == "collection")
			{
				self.updatecollection(value);
			}
			if(key == "objecteditor")
			{
				self.updateobjecteditor(value);
			}
			if(key == "general")
			{
				var x = 0;
			}
			return value;
		});
	}
	self.load = function(data)
	{
		var url = '/settings/settings.json';
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			dataType: "json",
			//async: false,
			success: function(data) {
				//var x = JSON.parse(data);
				self.update(data);
				//console.log("settings loaded");
			},
			error: function(e) {
				var x = 1;
				//console.log("Error on loading settings");
			}
			
			
		});
	}
	
	
}

var settings = new ViewModel_settings();
