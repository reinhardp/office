-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Erstellungszeit: 12. Mrz 2016 um 06:30
-- Server-Version: 10.1.8-MariaDB
-- PHP-Version: 5.5.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Datenbank: `collection`
--
CREATE DATABASE IF NOT EXISTS `collection` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `collection`;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `aplicationcollection`
--

DROP TABLE IF EXISTS `aplicationcollection`;
CREATE TABLE `aplicationcollection` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `aplicationcollection`
--

INSERT INTO `aplicationcollection` (`id`, `Name`, `link`, `image`) VALUES
(1, 'Products', NULL, NULL),
(2, 'Articles', NULL, NULL),
(3, 'Stock', NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `articles`
--

DROP TABLE IF EXISTS `articles`;
CREATE TABLE `articles` (
  `id` int(10) UNSIGNED NOT NULL,
  `Stockid` int(10) UNSIGNED NOT NULL,
  `State` int(11) NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `DEU` varchar(255) DEFAULT NULL,
  `ENG` varchar(255) DEFAULT NULL,
  `FRA` varchar(255) DEFAULT NULL,
  `DUT` varchar(255) DEFAULT NULL,
  `ITA` varchar(255) DEFAULT NULL,
  `shelf` varchar(20) DEFAULT NULL COMMENT 'das Regal',
  `Number` varchar(20) DEFAULT NULL,
  `Weight` int(10) UNSIGNED DEFAULT NULL COMMENT 'Gewicht in Gramm',
  `Available` int(11) UNSIGNED DEFAULT '0',
  `Reserved` int(11) UNSIGNED DEFAULT '0',
  `Send` int(11) UNSIGNED DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `articles`
--

INSERT INTO `articles` (`id`, `Stockid`, `State`, `Name`, `DEU`, `ENG`, `FRA`, `DUT`, `ITA`, `shelf`, `Number`, `Weight`, `Available`, `Reserved`, `Send`) VALUES
(1, 1, 1, 'Ball for the dog art', 'Ball für den Hund art', 'Ball for the dog art', NULL, NULL, NULL, 'PP_152', 'A20150600001', 200, 0, 0, 0),
(2, 1, 1, 'Frisbee for the dog art', 'Hundefrisbee art', 'Frisbee for the dog art', NULL, NULL, NULL, 'PP_156', 'A20150600002', 50, 0, 0, 0),
(3, 1, 1, 'Plush toy duck art', 'Plüschtier  Ente art', 'Plush toy duck art', NULL, NULL, NULL, 'PP_159', 'A20150600003', 60, 0, 0, 0),
(4, 1, 1, 'Plush toy Teddy art', 'Plüschtier Teddybär art', 'Plush toy Teddy art', NULL, NULL, NULL, 'PP_157', 'A20150600004', 360, 0, 0, 0),
(5, 1, 1, 'Article001', NULL, NULL, NULL, NULL, NULL, 'PP_0815', 'A20150600005', 100, 0, 0, 0);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `articlesfordelivery`
--

DROP TABLE IF EXISTS `articlesfordelivery`;
CREATE TABLE `articlesfordelivery` (
  `id` int(10) UNSIGNED NOT NULL,
  `Deliveriesid` int(10) UNSIGNED NOT NULL,
  `Articlesid` int(10) UNSIGNED NOT NULL,
  `amount` int(10) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `articlesforproducts`
--

DROP TABLE IF EXISTS `articlesforproducts`;
CREATE TABLE `articlesforproducts` (
  `id` int(10) UNSIGNED NOT NULL,
  `Productid` int(10) UNSIGNED NOT NULL,
  `Articleid` int(10) UNSIGNED NOT NULL,
  `Amount` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `articlesforproducts`
--

INSERT INTO `articlesforproducts` (`id`, `Productid`, `Articleid`, `Amount`) VALUES
(1, 1, 1, 2),
(2, 1, 3, 1),
(3, 2, 3, 2);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `countrycollection`
--

DROP TABLE IF EXISTS `countrycollection`;
CREATE TABLE `countrycollection` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(45) NOT NULL,
  `ISOCode` varchar(45) NOT NULL,
  `Currency` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `deliveries`
--

DROP TABLE IF EXISTS `deliveries`;
CREATE TABLE `deliveries` (
  `id` int(10) UNSIGNED NOT NULL,
  `date` date DEFAULT NULL,
  `expirationdate` date DEFAULT NULL,
  `amount` int(10) UNSIGNED DEFAULT NULL,
  `state` int(11) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `idgenerator`
--

DROP TABLE IF EXISTS `idgenerator`;
CREATE TABLE `idgenerator` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(45) NOT NULL,
  `Prefix` varchar(20) DEFAULT NULL,
  `UniqueID` varchar(45) NOT NULL,
  `Counnter` int(10) UNSIGNED NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `idgenerator`
--

INSERT INTO `idgenerator` (`id`, `Name`, `Prefix`, `UniqueID`, `Counnter`) VALUES
(1, 'Products', 'P', 'P2015060005', 5),
(2, 'Article', 'A', 'A20150600005', 5),
(3, 'Stock', 'S', 'S2015060002', 2),
(4, 'Category', 'C', 'C20150600004', 4),
(5, 'Account', 'A', 'A20150600002', 2),
(6, 'Invoice', NULL, '2015102000001', 1),
(7, 'Order', 'O', 'O20151000001', 1),
(8, 'CanceldInvoice', NULL, '2015102000001', 1),
(9, 'CanceledOrder', 'CO', 'CO20151000001', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `languagecollection`
--

DROP TABLE IF EXISTS `languagecollection`;
CREATE TABLE `languagecollection` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(45) NOT NULL,
  `ISOCode` varchar(45) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `languagecollection`
--

INSERT INTO `languagecollection` (`id`, `Name`, `ISOCode`) VALUES
(1, 'German', 'DEU'),
(2, 'English', 'ENG');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `productcategories`
--

DROP TABLE IF EXISTS `productcategories`;
CREATE TABLE `productcategories` (
  `id` int(10) UNSIGNED NOT NULL,
  `State` int(11) DEFAULT NULL,
  `name` varchar(255) DEFAULT NULL,
  `DEU` varchar(255) DEFAULT NULL,
  `ENG` varchar(255) DEFAULT NULL,
  `FRA` varchar(255) DEFAULT NULL,
  `DUT` varchar(255) DEFAULT NULL,
  `ITA` varchar(255) DEFAULT NULL,
  `Number` varchar(20) DEFAULT NULL,
  `methods` set('new','edit') DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `productcategories`
--

INSERT INTO `productcategories` (`id`, `State`, `name`, `DEU`, `ENG`, `FRA`, `DUT`, `ITA`, `Number`, `methods`) VALUES
(1, 1, 'Toys for the dog', 'Spielzeug für den Hund', 'Toys for the dog', NULL, NULL, NULL, 'C20150600001', ''),
(2, 1, 'Toys for the cat', 'Spielzeug für die Katze', 'Toys for the cat', NULL, NULL, NULL, 'C20150600002', ''),
(3, 1, 'Fees', 'Gebühren', 'Fees', NULL, NULL, NULL, 'C20150600003', NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `products`
--

DROP TABLE IF EXISTS `products`;
CREATE TABLE `products` (
  `id` int(10) UNSIGNED NOT NULL,
  `CategoryID` int(10) UNSIGNED NOT NULL,
  `State` int(11) NOT NULL COMMENT '1 == active 0 == inactive',
  `Creationdate` timestamp NULL DEFAULT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `DEU` varchar(255) DEFAULT NULL,
  `ENG` varchar(255) DEFAULT NULL,
  `FRA` varchar(255) DEFAULT NULL,
  `DUT` varchar(255) DEFAULT NULL,
  `ITA` varchar(255) DEFAULT NULL,
  `Taxcountry` varchar(20) DEFAULT NULL,
  `pricenetto` float DEFAULT NULL,
  `taxrate` int(10) UNSIGNED DEFAULT NULL,
  `pricebrutto` float DEFAULT NULL,
  `Number` varchar(20) DEFAULT NULL,
  `creator` int(10) UNSIGNED DEFAULT NULL,
  `methods` int(11) UNSIGNED DEFAULT NULL,
  `Calculated` tinyint(1) DEFAULT NULL,
  `image` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `products`
--

INSERT INTO `products` (`id`, `CategoryID`, `State`, `Creationdate`, `Name`, `DEU`, `ENG`, `FRA`, `DUT`, `ITA`, `Taxcountry`, `pricenetto`, `taxrate`, `pricebrutto`, `Number`, `creator`, `methods`, `Calculated`, `image`) VALUES
(1, 1, 1, '2015-10-03 20:47:34', 'Ball for the dog prod', '', 'Ball for the dog prod', NULL, NULL, NULL, 'Austria', 22.5, 20, NULL, 'P2015060001', NULL, NULL, 0, NULL),
(2, 1, 1, '2015-10-03 20:47:34', 'Plush toy Teddy prod', 'Plüschtier Teddybär prod', 'Plush toy Teddy prod', NULL, NULL, NULL, 'Austria', 5.3, 20, NULL, 'P2015060002', NULL, NULL, 0, NULL),
(3, 1, 1, '2015-10-03 20:47:34', 'Plush toy duck prod', 'Plüschtier  Ente prod', 'Plush toy duck prod', NULL, NULL, NULL, 'Austria', 6.55, 20, NULL, 'P2015060003', NULL, NULL, 0, NULL),
(4, 2, 1, '2015-10-03 20:47:34', 'Ball for the cat prod', 'Ball für die Katze prod', 'Ball for the cat prod', NULL, NULL, NULL, 'Austria', 5.6, 20, NULL, 'P2015060004', NULL, NULL, 0, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `stock`
--

DROP TABLE IF EXISTS `stock`;
CREATE TABLE `stock` (
  `id` int(10) UNSIGNED NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `DEU` varchar(255) DEFAULT NULL,
  `ENG` varchar(255) DEFAULT NULL,
  `FRA` varchar(255) DEFAULT NULL,
  `DUT` varchar(255) DEFAULT NULL,
  `ITA` varchar(255) DEFAULT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `Street` varchar(255) DEFAULT NULL,
  `Building` varchar(255) DEFAULT NULL,
  `Postalcode` varchar(20) DEFAULT NULL,
  `methods` int(11) DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `State` int(11) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `stock`
--

INSERT INTO `stock` (`id`, `Name`, `DEU`, `ENG`, `FRA`, `DUT`, `ITA`, `Country`, `Street`, `Building`, `Postalcode`, `methods`, `number`, `State`) VALUES
(1, 'Mainstock', 'Hauptlager', 'Mainstock', NULL, NULL, NULL, 'Austria', 'Ziegelofengasse', '39/6', '2485', NULL, 'S2015060001', 1);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `tabsforapplication`
--

DROP TABLE IF EXISTS `tabsforapplication`;
CREATE TABLE `tabsforapplication` (
  `id` int(10) UNSIGNED NOT NULL,
  `Aplicationid` int(10) UNSIGNED NOT NULL,
  `Name` varchar(45) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `link` varchar(255) DEFAULT NULL,
  `Relation` varchar(45) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `tabsforapplication`
--

INSERT INTO `tabsforapplication` (`id`, `Aplicationid`, `Name`, `type`, `link`, `Relation`) VALUES
(1, 1, 'Details', 'objecteditor', 'product/objecteditor.php', 'ProductObjecteditor'),
(2, 1, 'Articles', 'collection', 'product/articlecollecction.php', 'ArticlesforProduct'),
(3, 2, 'Details', 'objecteditor', 'article/objecteditor.php', 'ArticleObjecteditor'),
(4, 3, 'Details', 'objecteditor', 'stock/objecteditor.php', 'StockObjecteditor'),
(5, 3, 'Articles', 'collection', 'stock/articlecollection.php', 'Articles'),
(7, 3, 'Deliveries', 'collection', 'stock/deliverycollection.php', 'Deliveries');

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `taxcollection`
--

DROP TABLE IF EXISTS `taxcollection`;
CREATE TABLE `taxcollection` (
  `id` int(10) UNSIGNED NOT NULL,
  `Country` varchar(45) DEFAULT NULL,
  `ISOCode` varchar(20) DEFAULT NULL,
  `Taxrate` int(10) UNSIGNED DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `taxcollection`
--

INSERT INTO `taxcollection` (`id`, `Country`, `ISOCode`, `Taxrate`) VALUES
(1, 'Austria', 'DEU', 10),
(2, 'Austria', 'DEU', 20),
(3, 'Germany', 'DEU', 19);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `translationcollection`
--

DROP TABLE IF EXISTS `translationcollection`;
CREATE TABLE `translationcollection` (
  `idTranslationCollection` int(10) UNSIGNED NOT NULL,
  `Name` varchar(255) DEFAULT NULL,
  `DEU` varchar(255) DEFAULT NULL,
  `ENG` varchar(255) DEFAULT NULL,
  `FRA` varchar(255) DEFAULT NULL,
  `DUT` varchar(255) DEFAULT NULL,
  `ITA` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `translationcollection`
--

INSERT INTO `translationcollection` (`idTranslationCollection`, `Name`, `DEU`, `ENG`, `FRA`, `DUT`, `ITA`) VALUES
(1, 'Building', 'Hausnummer', 'Building', '', '', ''),
(2, 'FirstName', 'Vorname', 'First Name', '', '', ''),
(3, 'LastName', 'Nachname', 'Last Name', '', '', ''),
(4, 'Countrycode', 'Ländercode', 'Countrycode', '', '', ''),
(5, 'Title', 'Titel', 'Title', '', '', ''),
(6, 'Country', 'Land', 'Country', '', '', ''),
(7, 'Street', 'Straße', 'Street', '', '', ''),
(8, 'Product', 'Produkt', 'Product', '', '', ''),
(9, 'Products', 'Produkte', 'Products', '', '', ''),
(10, 'Article', 'Artikel', 'Article', '', '', ''),
(11, 'Account', 'Konto', 'Account', '', '', ''),
(12, 'Customer', 'Kunde', 'Customer', '', '', ''),
(13, 'Articles', 'Artikel', 'Articles', '', '', ''),
(14, 'German', 'Deutsch', 'German', '', '', ''),
(15, 'English', 'Englisch', 'English', '', '', ''),
(16, 'Stock', 'Lager', 'Stock', NULL, NULL, NULL),
(17, 'Deliveries', 'Anlieferungen', 'Deliveries', NULL, NULL, NULL),
(18, 'shelf', 'Regal', 'Shelf', NULL, NULL, NULL),
(19, 'Weight', 'Gewicht', 'Weight', NULL, NULL, NULL),
(20, 'Available', 'Vorhanden', 'Available', NULL, NULL, NULL),
(21, 'Reserved', 'Reserviert', 'Reserved', NULL, NULL, NULL),
(22, 'DEU', 'Deutsch', 'German', 'Anglais', NULL, NULL),
(23, 'ENG', 'Englisch', 'English', 'Anglais', NULL, NULL),
(24, 'Postalcode', 'Postleitzahl', 'Postal code', NULL, NULL, NULL),
(25, 'FRA', 'Französisch', 'French', NULL, NULL, NULL),
(26, 'DUT', 'Holländisch', 'Dutch', NULL, NULL, NULL),
(27, 'ITA', 'Italienisch', 'Italian', NULL, NULL, NULL),
(28, 'Save', 'Speichern', 'Save', NULL, NULL, NULL),
(29, 'Cancel', 'Abbrechen', 'Cancel', NULL, NULL, NULL),
(30, 'Edit', 'Bearbeiten', 'Edit', NULL, NULL, NULL),
(31, 'Expiration date', 'Ablaufdatum', 'Expiration date', NULL, NULL, NULL),
(32, 'Amount', 'Anzahl', 'Amount', NULL, NULL, NULL),
(33, 'Add Article', 'Artikel hinzufügen', 'Add Article', NULL, NULL, NULL),
(34, 'Search', 'Suchen', 'Search', NULL, NULL, NULL);

-- --------------------------------------------------------

--
-- Tabellenstruktur für Tabelle `usercollection`
--

DROP TABLE IF EXISTS `usercollection`;
CREATE TABLE `usercollection` (
  `id` int(10) UNSIGNED NOT NULL,
  `accountid` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `name` varchar(255) NOT NULL,
  `pwd` varchar(255) NOT NULL,
  `language` varchar(3) NOT NULL,
  `officeaccess` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `administrationaccess` int(10) UNSIGNED NOT NULL DEFAULT '0',
  `state` int(10) UNSIGNED NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- Daten für Tabelle `usercollection`
--

INSERT INTO `usercollection` (`id`, `accountid`, `name`, `pwd`, `language`, `officeaccess`, `administrationaccess`, `state`) VALUES
(1, 0, 'reinhardp', '4reinhhard4', 'DEU', 1, 0, 1);

--
-- Indizes der exportierten Tabellen
--

--
-- Indizes für die Tabelle `aplicationcollection`
--
ALTER TABLE `aplicationcollection`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `articles`
--
ALTER TABLE `articles`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Articles_FKIndex1` (`Stockid`);

--
-- Indizes für die Tabelle `articlesfordelivery`
--
ALTER TABLE `articlesfordelivery`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Articlesfordelivery_FKIndex1` (`Deliveriesid`),
  ADD KEY `Articlesfordelivery_FKIndex2` (`Articlesid`);

--
-- Indizes für die Tabelle `articlesforproducts`
--
ALTER TABLE `articlesforproducts`
  ADD PRIMARY KEY (`id`),
  ADD KEY `ArticlesforProducts_FKIndex1` (`Productid`),
  ADD KEY `ArticlesforProducts_FKIndex2` (`Articleid`);

--
-- Indizes für die Tabelle `countrycollection`
--
ALTER TABLE `countrycollection`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `deliveries`
--
ALTER TABLE `deliveries`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `idgenerator`
--
ALTER TABLE `idgenerator`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `languagecollection`
--
ALTER TABLE `languagecollection`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `productcategories`
--
ALTER TABLE `productcategories`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD KEY `Products_FKIndex1` (`CategoryID`);

--
-- Indizes für die Tabelle `stock`
--
ALTER TABLE `stock`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `tabsforapplication`
--
ALTER TABLE `tabsforapplication`
  ADD PRIMARY KEY (`id`),
  ADD KEY `TabsforApplication_FKIndex1` (`Aplicationid`);

--
-- Indizes für die Tabelle `taxcollection`
--
ALTER TABLE `taxcollection`
  ADD PRIMARY KEY (`id`);

--
-- Indizes für die Tabelle `translationcollection`
--
ALTER TABLE `translationcollection`
  ADD PRIMARY KEY (`idTranslationCollection`);

--
-- Indizes für die Tabelle `usercollection`
--
ALTER TABLE `usercollection`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT für exportierte Tabellen
--

--
-- AUTO_INCREMENT für Tabelle `aplicationcollection`
--
ALTER TABLE `aplicationcollection`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `articles`
--
ALTER TABLE `articles`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT für Tabelle `articlesfordelivery`
--
ALTER TABLE `articlesfordelivery`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `articlesforproducts`
--
ALTER TABLE `articlesforproducts`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `countrycollection`
--
ALTER TABLE `countrycollection`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `deliveries`
--
ALTER TABLE `deliveries`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT für Tabelle `idgenerator`
--
ALTER TABLE `idgenerator`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;
--
-- AUTO_INCREMENT für Tabelle `languagecollection`
--
ALTER TABLE `languagecollection`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
--
-- AUTO_INCREMENT für Tabelle `productcategories`
--
ALTER TABLE `productcategories`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `products`
--
ALTER TABLE `products`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
--
-- AUTO_INCREMENT für Tabelle `stock`
--
ALTER TABLE `stock`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
--
-- AUTO_INCREMENT für Tabelle `tabsforapplication`
--
ALTER TABLE `tabsforapplication`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT für Tabelle `taxcollection`
--
ALTER TABLE `taxcollection`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
--
-- AUTO_INCREMENT für Tabelle `translationcollection`
--
ALTER TABLE `translationcollection`
  MODIFY `idTranslationCollection` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=35;
--
-- AUTO_INCREMENT für Tabelle `usercollection`
--
ALTER TABLE `usercollection`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- Metadaten
--
USE `phpmyadmin`;

--
-- Metadaten für aplicationcollection
--

--
-- Metadaten für articles
--

--
-- Metadaten für articlesfordelivery
--

--
-- Metadaten für articlesforproducts
--

--
-- Metadaten für countrycollection
--

--
-- Metadaten für deliveries
--

--
-- Metadaten für idgenerator
--

--
-- Metadaten für languagecollection
--

--
-- Metadaten für productcategories
--

--
-- Metadaten für products
--

--
-- Metadaten für stock
--

--
-- Metadaten für tabsforapplication
--

--
-- Metadaten für taxcollection
--

--
-- Metadaten für translationcollection
--

--
-- Metadaten für usercollection
--

--
-- Metadaten für collection
--

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
