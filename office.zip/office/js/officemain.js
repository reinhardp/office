var applicationindex = -1;
var currentapplication = -1;
var currenttab = undefined;
//sessionStorage['currentlanguage'] = "DEU";

sessionStorage['defaultappindex'] = 0;
sessionStorage['defaultapptabindex'] = 0;
sessionStorage['defaultlistindex'] = 0;

sessionStorage['selectedappindex'] = -1;
sessionStorage['selectedapptabindex'] = -1;
sessionStorage['selectedlistindex'] = -1;

var htmlloaded = new Array();

// für calls method
// variablen: $id,$parentid,$childid, $usemoretabs == true or false

function ViewModel_applicationtabsmoretabs()
{
	var self = this;
	self.moretabs = ko.observableArray();
	
	self.removealltabs = function(event,data)
	{
		self.moretabs.removeAll();
	}
	self.removetab = function(event,data)
	{
		
	}
	self.addtab = function(data,event)
	{
		self.moretabs.push(data);
	}
	self.activatetab = function(event,data)
	{
		
	}
	self.deactivatetab = function(event,data)
	{
		
	}

}
var applicationtabsmoretabs = new ViewModel_applicationtabsmoretabs();
ko.applyBindings(applicationtabsmoretabs,document.getElementById("applicationtabsmoretabscoontainer"));

// objecteditor
function ViewModel_ObjectEditor()
{
	var self = this;
	self.attributes = ko.observableArray();
	self.links = ko.observableArray();
	self.header = ko.observableArray();
	self.html = ko.observable();
	self.writeable = ko.observable(false);
	self.hasimage =  ko.observable(false);
	self.image = ko.observable();
	self.arr = Array();
	self.changedattributes = ko.observableArray();
	self.cancel = function(event, data)
	{
		self.writeable(false);
		self.load();
		var x = 1;
	}
	//self.prototype.change = function(event,data)
	self.changed = function(data,event)
	{
		var str = '{ "name" : "' + data.name + '",' + '"value" : "' + data.value + '" }';
		var obj = JSON.parse(str);
		
		self.changedattributes.push(obj);
		return true;
	}

	self.edit = function(event, data)
	{
		self.writeable(true)
		// var cancelsavebuttons = document.getElementById('defaultobjecteditorhtmlsavecancel');
		// if (cancelsavebuttons != undefined)
		// {
			// $("#defaultobjecteditorhtmlsavecancel").show();
			// $("#defaultobjecteditorhtmledit").hide();
		// }
		var x = 1;
	}
	self.save = function(event, data)
	{
		self.writeable(false);
		var data = self.changedattributes();
		if(data.length == 0) { 
			console.log("self.save return 0");
			return 0; 
		}
		var getid = self.attributes();
		var ndata = Array();
		var xdata = ko.toJSON(data);
		//var xdata = ko.toJS(data);
		var id;
		for (i = 0; i < getid.length;i++)
		{
			var x = getid[i];
			if(x.attrtype == 0)
			{
				id = x.value;
			} 
			var x = 1;

		}
		var php = self.links()[0].php;
		var url = '/php/'+php+'?filter='+id;
		var x = 1;
		$.ajax({
			url: url,
			//dataType: 'json',
			type: 'post',
			//contentType: 'application/json',
			data: data,
			//processData: false,
			success: function( data, textStatus, jQxhr ){
				//$('#response pre').html( JSON.stringify( data ) );
				self.changedattributes.removeAll();
				applicationtabsmoretabs.removealltabs();
				self.load();
				var x = 0;
			},
			error: function( jqXhr, textStatus, errorThrown ){
				console.log( errorThrown );
			}
		});		
	}
	self.appendchildren = function(data)
	{
		var element = document.getElementById("obecteditordefault");
		
		$.ajax({
		url: url,
		cache: false,
		//async: false
		})
		.done(function( html ) {
				var loaded = $( "#obecteditordefaulthtml" ).append( html );

		});

	}
	self.removechildren = function()
	{
		var c = document.getElementById("obecteditordefault").childNodes;
		var len = document.getElementById("obecteditordefault").childNodes.length;
		//element.parentNode.removeChild(element);

		
	}
	
	self.translate = function(name)
	{
		//return name;
		return Translations.translate(name);
	}
	
	
	self.update = function(data,relation)
	{
		var obj = jQuery.parseJSON(data);
		self.attributes.removeAll();
		self.links.removeAll();
		applicationtabsmoretabs.removealltabs();

		self.changedattributes.removeAll();
		//var theader = settings.getheadercollection(relation);
		var tlinks = settings.getlinksobjecteditor(relation);

		if(tlinks != undefined)
		{
			$.each(tlinks, function(index,item) {
				self.links.push(item);
			});
			
		}
		
		$.each(obj, function(index,data) {
			if(data.attrtype != undefined)
			{
				if(data.attrtype == 10)
				{
					if(data.value != undefined)
					{
						self.hasimage(true);
						self.image(data.value);
					} else
					{
						var img = '/images/product.jpg';
						self.hasimage(true);
						self.image(img);
						
					}
				}
				self.attributes.push(data);
			}
		});
		var x = 1;
		//console.log("objecteditor updated relation: "+relation);
	}
	
	self.load = function()
	{
		if(sessionStorage['link'] === undefined) {
			console.log("self.load return 0");
			return 0;
		}
		var type = sessionStorage['selectedtype'];
		var relation = sessionStorage['Relation'];
		var listitem = sessionStorage['selectedlistitem'];
		var url = '/php/' + sessionStorage['link']+'?filter='+listitem;
		var x=1;
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data)
			{
				//self.removechildren();
				self.attributes.removeAll();
				//console.log("vor settings.loadobjecteditor");
				settings.loadobjecteditor(relation);
				//console.log("nach settings.loadobjecteditor");
				self.update(data,relation);
				
			},
			error: function(e)
			{
				var x = 1;
			}
		});
	}
}
var objecteditor = new ViewModel_ObjectEditor();

function ViewModel_righttopheader()
{
	var self = this;
	self.header1 = ko.observable('');
	self.header2 = ko.observable('');
	self.header3 = ko.observable('');
	
	self.update = function(data)
	{
		if(data === undefined || data == "") { 
		return 0; 
		}
		var obj = jQuery.parseJSON(data);
		self.header1(obj[0].header1);
		self.header2(obj[0].header2);
		self.header3(obj[0].header3);
	}
	self.load = function(id)
	{
		var url = "/php/rtopheader.php?filter="+id+"&application="+sessionStorage['currentapplication'];
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data) {
				//var x = JSON.parse(data);
				self.update(data);
				//console.log("righttopheader loaded");
			},
			error: function(e)
			{
				var x = 1;
			}
			
		});
		
	}
	
}
var righttopheader = new ViewModel_righttopheader();
ko.applyBindings(righttopheader,document.getElementById("maincontainerreighttop"));


function listitem(index,data)
 {
	var self = this;
	self.information1 = ko.observable('');
	self.information2 = ko.observable('');
	self.information3 = ko.observable('');
	self.information4 = ko.observable('');
	self.id = ko.observable(data.id);
	self.listindex = ko.observable(index);
	
	if(data.information1)
	{
		self.information1 = ko.observable(data.information1);
	}
	if(data.information2)
	{
		self.information2 = ko.observable(data.information2);
	}
	if(data.information3)
	{
		self.information3 = ko.observable(data.information3);
	}
	if(data.information4)
	{
		self.information4 = ko.observable(data.information4);
	}
}

function ViewModel_list()
{
	var self = this;
	self.mainurl = '/php/getlist.php?filter=';
	self.listdata = ko.observableArray();
	self.selectedID = ko.observable('');
	self.selected = -1;
	self.getlistdatazero = function()
	{
		return self.listdata()[0];
	}
	self.selectlistitem = function(event,index)
	{
		var ID = event.id();
		self.selectedID = ko.observable(ID);
		sessionStorage['selectedlistitem'] = ID;
		sessionStorage['listclicked'] = event.listindex();
		righttopheader.load(ID);
		var type = sessionStorage['selectedtype'];
		if (type == "collection")
		{
			collection.load();
		}
		if (type == "objecteditor")
		{
			objecteditor.load();
		}
		
	}
	self.update = function(data)
	{
		var temp = JSON.parse(data);
		$.each(temp, function(index,item) {
			self.listdata.push(new listitem(index,item));
		});
		if(sessionStorage['listclicked'] === undefined)
		{
			sessionStorage['listclicked'] = 0;
			var item = self.listdata()[0];
			var ID = item.id();
			sessionStorage['selectedlistitem'] = ID;
			righttopheader.load(ID);
			if(sessionStorage['selectedtype'] == "collection")
			{
				collection.load();
			}
			if(sessionStorage['selectedtype'] == "objecteditor")
			{
				objecteditor.load();
			}
			
			var x = 0;
		} else
		{
			var item = self.listdata()[sessionStorage['listclicked']];
			if(item === undefined)
			{
				item = self.listdata()[0];
			}
			var ID = item.id();
			sessionStorage['selectedlistitem'] = ID;
			righttopheader.load(ID);
			if(sessionStorage['selectedtype'] == "collection")
			{
				collection.load();
			}
			if(sessionStorage['selectedtype'] == "objecteditor")
			{
				objecteditor.load();
			}
			var x = 0;
		}
	}
	$( "#application").on( "Applications",  function(event,param)
	{
		self.load(param.id);
		//var tab = applicationtabs.gettabzero();
		//applicationtabs.tabselected(param, undefined);
		
	});
	self.load = function(data)
	{
		var url = self.mainurl+data;
		var x = 1;
		$.ajax( {
			url: url,
			//contentType: 'charset=utf-8',
			success: function(data) {
				//var x = JSON.parse(data);
				self.listdata.removeAll();
				self.update(data);
				//console.log("list loaded");

			}
			
			
		});
	}
	
	
}
var list = new ViewModel_list();
ko.applyBindings(list,document.getElementById("maincontainerlist"));


//ko.applyBindings(Translations);
//Translations.load("deu");
function ViewModel_lefttopheader()
{
	var self = this;
	self.header = ko.observable('');
	self.appid = ko.observable('');
	self.translate = function(name)
	{
		return Translations.translate(name());
	}
	
	self.update = function(data)
	{
		self.header(data[0]);
		self.appid(data[1]);
	}
}
var lefttopheader = new ViewModel_lefttopheader();
ko.applyBindings(lefttopheader,document.getElementById("maincontainerlefttop"));

function ViewModel_applicationtabs()
{
	var self = this;
	var murl = '/php/applicationtabs.php?filter=';
	self.tabs = ko.observableArray();
	self.gettabzero = function()
	{
		return self.tabs()[0];
	}
	
	self.tabselected = function(event,data)
	{
		//console.log("self.tabselected called");
		sessionStorage['selectedtab'] = event.id;
		sessionStorage['selectedtype'] = event.type;
		sessionStorage['link'] = event.link;
		sessionStorage['Relation'] = event.relation;
		if (sessionStorage['selectedtype'] === "collection")
		{
			settings.loadcollection(event.relation);
			collection.load();
			var x = 1;
		}
		if (sessionStorage['selectedtype'] === "objecteditor")
		{
			settings.loadobjecteditor(event.relation);
			objecteditor.load();
			var x = 1;
		}
		main.setcurrenttype(event.type);
	}
	self.update = function(data)
	{
		self.tabs.removeAll();
		var temp = JSON.parse(data);
		$.each(temp, function(index,item) {
			self.tabs.push(item);
		});
		 var x = 0;
	}
	self.translate = function(name)
	{
		return Translations.translate(name);
	}
	self.load = function(id)
	{
		var url = murl + id;
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data)
			{
				self.update(data);
				//console.log("applicationtabs loaded");
			}
		});
	}
	
}
var applicationtabs = new ViewModel_applicationtabs();
ko.applyBindings(applicationtabs,document.getElementById("applicationtabs"));

function Applications()
//var Applications =
{
	var self = this;
/*	if (currentapplication === -1)
	{
		currentapplication = 1;
	}
*/
	this.applications = ko.observableArray();
	self.url = '/php/applications.php?filter=';
	self.translate = function(name)
	{
		return Translations.translate(name);
	}
	self.update = function(data)
	{
		var temp = JSON.parse(data);
		$.each(temp, function(index,item) {
			self.applications.push(item
/*			{
				item
				name: item.name,
				value: item.value
			}*/
			)
		});
		 var x = 0;
	}
	this.gettabs = function(index)
	{
		var id = index.id;
		//console.log("Applications: currentid: "+id);
		
		//currentapplication = id;
		sessionStorage['currentapplication'] = id;
		sessionStorage['currentapplicationname'] = index.name;
		lefttopheader.update(Array(index.name,index.id));
		applicationtabs.load(id);
	}
	//console.log("X Applications: currentapplication: "+sessionStorage['currentapplication']);
	if(sessionStorage['currentapplication'] === undefined)
	{
		//currentapplication = 1;
		sessionStorage['currentapplication'] = 1;
		sessionStorage['currentapplicationname'] = "Products";
		self.gettabs({'id': 1,'name': "Products"});
		//mouseupApplicationHandler(sessionStorage['currentapplication']);
		//lefttopheader.update(self.translate("Products"));
		//$("#application").bind("Applications", { 'id': sessionStorage['currentapplication'], 'name': sessionStorage['currentapplicationname']});
	} else {
		//self.gettabs({'id': currentapplication});
		//self.gettabs({'id': sessionStorage['currentapplication']});
		self.gettabs({'id': sessionStorage['currentapplication'],'name': sessionStorage['currentapplicationname']});
		//sessionStorage['currentapplication'] = currentapplication;
		//mouseupApplicationHandler(sessionStorage['currentapplication']);
		//$("#application").bind("Applications", { 'id': sessionStorage['currentapplication'], 'name': sessionStorage['currentapplicationname']});
	}
	$("#application").trigger("Applications", { 'id': sessionStorage['currentapplication'], 'name': sessionStorage['currentapplicationname']});
	self.load = function()
	{
		var url = self.url;
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data)
			{
				self.update(data);
			}
		});
	}
	
	
}
var ViewModel_Applications = new Applications();
ko.applyBindings(ViewModel_Applications, document.getElementById("applicationcontainer"));
//ViewModel_Applications.load();
function ViewModel_collectionitem(data,header)
{
	var self = this;
	if (data.id != undefined)
	{
		self.id = data.id;
	}
	if (header != undefined)
	{
		self.width = header.width;
		self.style = header.style;
	}
	self.value = data.value;
}
function ViewModel_links(data)
{
	var self = this;
	
}
function ViewModel_collection() {
	var self = this;
	self.items = ko.observableArray();
	self.header = ko.observableArray();
	self.links = ko.observableArray();
	self.html = ko.observable();
	self.search = ko.observableArray();
	self.close = ko.observableArray();
	self.writeable = ko.observable(false);
	self.remove = function(data)
	{
		var x = 1;
	}
	self.click = function(data,event)
	{
		if(data.method != undefined && data.method != "")
		{
			if(data.method == "delete")
			{
				console.log("method remove called!");
				self.remove(data);
			}
			if(data.method == "edit")
			{
				console.log("method edit called!");
				self.edit(data);
			}
			if(data.method == "add")
			{
				if(data.type == "collection")
				{
					self.items.removeAll();
					self.links.removeAll();
					self.header.removeAll();
					self.search.removeAll();
					settings.loadcollection(data.internalname,data.removeable);
					
				}
				console.log("method add called!");
			}
		}
		var x = 1;
	}
	self.edit = function(data,event)
	{
		var x = 0;
	}
	self.changed = function(data)
	{
		var x = 0;
	}
	self.translate = function(name)
	{
		return Translations.translate(name);
	}
	self.update = function(data,relation)
	{
		self.items.removeAll();
		self.header.removeAll();
		self.links.removeAll();
		self.search.removeAll();
		var theader = settings.getheadercollection(relation);
		var tlinks = settings.getlinkscollection(relation);
		if(tlinks != undefined)
		{
			$.each(tlinks, function(index,item) {
				self.links.push(item);
			});
			
		}
		if( theader != undefined)
		{
			$.each(theader, function(index,item) {
				self.header.push(item);
			});
		}
		if(data == "")
		{ 
			console.log("self.update return 0");
			return 0;
		}
		var temp = JSON.parse(data);
		if(temp.length == 0 ) { 
			console.log("self.update return 0");
			return 0; 
		}
		if(temp[0].search != undefined)
		{
			var tsearch = temp[0].search;
			$.each(tsearch, function(index,item) {
				self.search.push(item);
			});
			
		}
		if(temp[0].links != undefined)
		{
			var tlinks = temp[0].links;
			$.each(tlinks, function(index,item) {
				self.links.push(item);
			});
		}
		$.each(temp, function(index,item) {
		//var h = theader[index];
		//$.each(data, function(index,item) {
			//$.each(item, function(index, iitem) {
				//var h = theader[index];
				//self.items.push(new ViewModel_collectionitem(item,h))
			//});
			if(item.links == undefined)
			{
				self.items.push(item);
			}
		});
	var x = 1;
	}
	self.load = function()
	{
		if(sessionStorage['link'] === undefined) {
			console.log("self.load return 0");
			return 0;
		}
		var type = sessionStorage['selectedtype'];
		var relation = sessionStorage['Relation'];
		var listitem = sessionStorage['selectedlistitem'];

		var url = '/php/' + sessionStorage['link']+'?filter='+listitem;
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data)
			{
				settings.loadcollection(relation);
				self.update(data,relation);
				applicationtabsmoretabs.removealltabs();
/*				$.each(settings.header, function(index,data) {
						self.header.push(data);
				});
*/				
				var x = 1;
			},
			error: function(e)
			{
				var x = 1;
			}
		});
		
	}
}

var collection = new ViewModel_collection();
//ko.applyBindings(collection, document.getElementById("collectioncontainer"));

function ViewModel_main()
{
	var self = this;
	self.width = window.innerWidth;
	var height = window.innerHeight;
	var listcontainer = document.getElementById("maincontainerleftbottom");
	self.currenttype = undefined;
	self.setcurrenttype = function(type)
	{
		self.currenttype = type;
	}
	if (sessionStorage['listselected'] === undefined)
	{
		sessionStorage['listselected'] = 1;
	}
	if (sessionStorage['selectedtab'] == undefined) {
		sessionStorage['selectedtab'] = 1;
	}
	listcontainer.clientHeight = height*0.75 + 'px';
	if(sessionStorage['currentapplication'] === undefined)
	{
		sessionStorage['currentapplication'] = 1;
		sessionStorage['currentapplicationname'] = "Products";
	}
	//applicationtabs.tabselected(); // ????????????
	self.applications = ko.observableArray();
	//var ViewModel_Applications = new Applications();
	//var Translations = new ViewModel_Translations();
	self.load = function()
	{
		//console.log("Loading main");
		Translations.load();
		settings.load();
		ViewModel_Applications.load();
		//Applications.load();
		//self.applications(ViewModel_Applications.getapps());
		
	}

}
//Translations.load("deu");
var main = new ViewModel_main();
main.load();
//settings.getcollection("articles");
/*	$(document).ready(function() {
		// dieser Code wird ausgeführt, wenn das HTML-Dokument
		// geladen – also das DOM fertig aufgebaut – ist.
		self.element = document.getElementById("applicationcontainer");
	});	
	
*/
mouseupApplicationHandler = function(data)
{
	var Id = data.id;
	sessionStorage['listclicked'] = 0;
	applicationtabs.load(Id);
	list.load(Id);
	var x = list.getlistdatazero();
	var temp = { 'id': x.id() };
	var tab = applicationtabs.gettabzero();
	//applicationtabs.tabselected(tab, undefined);

}
collectionclickHandler = function(data,event)
{
	collection.click(data,event);
	// if (data.usemoretabs == true)
	// {
		// applicationtabsmoretabs.addtab(data);
	// }
	var x = 1;
}
function change(event, data)
{
	var x = 1;
	return true;
}
