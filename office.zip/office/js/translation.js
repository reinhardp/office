function ViewModel_Translations()
{
	var self = this;
	self.mainurl = '/php/translations/translations.php?filter=';
	this.items = ko.observableArray();
	self.update = function(data)
	{
		//self.items = ko.mapping.fromJS(data);
		var temp = JSON.parse(data);
/*		self.itmes($.map(temp, function(item) {
			return new add(item);
		}));
*/
		$.each(temp, function(index,item) {
			self.items.push(item
/*			{
				item
				name: item.name,
				value: item.value
			}*/
			)
		});
		//console.log("updated translations");
		 var x = 0;
	}
	self.translate = function(name)
	{
		for (i in self.items())
		{
			var x = self.items()[i].name;
			if (name === x)
			{
				return self.items()[i].value;
			}
		}
		return name;
		
	}
	self.load = function(language)
	{
		var str = "Currentlanguage "+language;
		//console.log(str);
		if(language === undefined)
		{
			language = "DEU";
		}
		var url = self.mainurl;
		var x = 1;
		$.ajax( {
			url: url,
			//async: false,
			contentType: 'charset=utf-8',
			success: function(data) {
				//var x = JSON.parse(data);
				self.items.removeAll();
				self.update(data);
				//console.log("translations loaded");
			}
			
			
		});
		
	}
	
}
var Translations = new ViewModel_Translations();
//Translations.load(sessionStorage['currentlanguage']);
