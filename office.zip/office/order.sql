CREATE TABLE creditcard (
  idcreditcard INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  company Varchar(45) NULL,
  PRIMARY KEY(idcreditcard)
);

INSERT INTO creditcard(idcreditcard, company) VALUES(1, 'VISA');

INSERT INTO creditcard(idcreditcard, company) VALUES(2, 'Mastercard'); 


CREATE TABLE productgroup (
  idproductgroup INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  groupname Varchar(45) NULL,
  PRIMARY KEY(idproductgroup)
);

INSERT INTO productgroup(idproductgroup, groupname) VALUES(1, 'Books');

INSERT INTO productgroup(idproductgroup, groupname) VALUES(2, 'DVDs'); 

INSERT INTO productgroup(idproductgroup, groupname) VALUES(3, 'Software'); 


CREATE TABLE product (
  idproduct INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  idproductgroup INTEGER UNSIGNED NOT NULL,
  name Varchar(45) NULL,
  ean Varchar(20) NULL,
  price FLOAT(10,2) NULL,
  info TEXT NULL,
  pic LONGBLOB NULL,
  PRIMARY KEY(idproduct),
  INDEX product_name(name, info(100)),
  UNIQUE INDEX product_ean(ean)
)
AUTO_INCREMENT = 100
CHECKSUM = 1
PASSWORD = "theproducts123";

INSERT INTO product(idproduct, idproductgroup, name, ean, price, pic)
VALUES(1, 1, 'Learning C++', '154365423', 42.23, NULL);

INSERT INTO product(idproduct, idproductgroup, name, ean, price, pic)
VALUES(2, 1, 'Lord of the Rings - Part I', '437634323', 23.15, NULL);

INSERT INTO product(idproduct, idproductgroup, name, ean, price, pic)
VALUES(3, 1, 'Alice in Wonderland', '34631764345', 14.20, NULL);


-- ------------------------------------------------------------
-- This Table stores all Online Customers.
-- ------------------------------------------------------------

CREATE TABLE onlinecustomer (
  idonlinecustomer INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  idcreditcard INTEGER UNSIGNED NOT NULL,
  name VARCHAR(30) NULL,
  address1 VARCHAR(80) NULL,
  address2 VARCHAR(80) NULL,
  region Varchar(45) NULL,
  city Varchar(45) NULL,
  zip VARCHAR(6) NULL,
  phone Varchar(20) NULL,
  creditcardnr VARCHAR(20) NULL,
  creditcarddate DATE NULL,
  PRIMARY KEY(idonlinecustomer)
);

INSERT INTO onlinecustomer(idonlinecustomer, idcreditcard, name, address1, address2, 
 region, city, zip, phone, creditcardnr, creditcarddate) 
VALUES(1, 1, 'Jack Foley', 'Goodthings Inc.', 'Uptown Street 4', 
 'US', 'New York', '12345', '0243 43 543', '1234 3412 2432 3341', '2004-03-01');

INSERT INTO onlinecustomer(idonlinecustomer, idcreditcard, name, address1, address2,  
 region, city, zip, phone, creditcardnr, creditcarddate)  
VALUES(2, 2, 'Ray Berger', 'Pensilvaniastr.5', '',  
 'US', 'Washington', '54321', '0543 639 53', '8641 3853 2964 2853', '2003-07-01');


CREATE TABLE carthasproduct (
  idonlinecustomer INTEGER UNSIGNED NOT NULL,
  idproduct INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(idonlinecustomer, idproduct),
  FOREIGN KEY(idonlinecustomer)
    REFERENCES onlinecustomer(idonlinecustomer)
      ON DELETE RESTRICT
      ON UPDATE RESTRICT
);

INSERT INTO carthasproduct(idonlinecustomer, idproduct) VALUES(2, 3);

INSERT INTO carthasproduct(idonlinecustomer, idproduct) VALUES(2, 2); 


CREATE TABLE onlineorder (
  idonlineorder INTEGER UNSIGNED NOT NULL AUTO_INCREMENT,
  idonlinecustomer INTEGER UNSIGNED NOT NULL,
  date DATETIME NULL,
  shippingaddress TEXT NULL,
  PRIMARY KEY(idonlineorder)
);

INSERT INTO onlineorder(idonlineorder, idonlinecustomer, date, shippingaddress) 
VALUES(1, 1, '2003-04-23', 'Same as billing address');


CREATE TABLE onlineorderhasproduct (
  idonlineorder INTEGER UNSIGNED NOT NULL,
  idproduct INTEGER UNSIGNED NOT NULL,
  PRIMARY KEY(idonlineorder, idproduct),
  FOREIGN KEY(idonlineorder)
    REFERENCES onlineorder(idonlineorder)
      ON DELETE CASCADE
      ON UPDATE CASCADE
);

INSERT INTO onlineorderhasproduct(idonlineorder, idproduct) VALUES(1, 1);

INSERT INTO onlineorderhasproduct(idonlineorder, idproduct) VALUES(1, 2); 



