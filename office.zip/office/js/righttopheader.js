function ViewModel_righttopheader()
{
	var self = this;
	self.header1 = ko.observable('');
	self.header2 = ko.observable('');
	self.header3 = ko.observable('');
	
	self.update = function(data)
	{
		var obj = jQuery.parseJSON(data);
		self.header1(obj[0].header1);
		self.header2(obj[0].header2);
		self.header3(obj[0].header3);
	}
	self.load = function(id)
	{
		var url = "/php/rtopheader?filter="+id+"&language="+sessionStorage['currentlanguage']+"&application="+sessionStorage['currentapplication'];
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data) {
				//var x = JSON.parse(data);
				self.update(data);
				console.log("righttopheader loaded");
			},
			error: function(e)
			{
				var x = 1;
			}
			
		});
		
	}
	
}
var righttopheader = new ViewModel_righttopheader();
ko.applyBindings(righttopheader,document.getElementById("maincontainerreighttop"));
