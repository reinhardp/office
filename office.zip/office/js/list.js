unction ViewModel_listitem(data)
{
	var self = this;
	self..ID = ko.observable(data.id);
	self.information1 = ko.observable(data.information1);
	self.information2 = ko.observable(data.information2);
	self.information3 = ko.observable(data.information3);
	self.information4 = ko.observable(data.information4);
	
	
}

function ViewModel_list()
{
	var self = this;
	self.mainurl = '/php/list.php?filter=';
	self.list = ko.observableArray();
	self.translate = function(name)
	{
		return Translations.translate(name);		
	}
	self.update = function(data)
	{
		$.each(temp, function(index,item) {
			self.list.push(
			{
				return new ViewModel_listitem(item);
				//var x = 1;
			})
		});
	}
	self.load = function(index,data)
	{
		var url = self.mainurl+index;
		var x = 1;
		$.ajax( {
			url: url,
			contentType: 'charset=utf-8',
			success: function(data) {
				//var x = JSON.parse(data);
				self.update(data);
			}
			
			
		});
		
	}
	
}
var list = new ViewModel_list();
ko.applyBindings(list,document.getElementById("maincontainerlist"));
